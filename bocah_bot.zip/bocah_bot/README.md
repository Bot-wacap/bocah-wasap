# 🤖UWIWBOCAH🤖
BOT WHATSAPP TERMUX ONLY BY UWIWBOCAH ID

### Alat dan Bahan
Siapin alat dan bahannya.
```bash
> niat
> 2 handphone (1 buat jalanin sc, 1 buat scan kode qr kak)
> jaringan internet kenceng,kuota+
> penyimpanan yang memadai
> aplikasi whatsapp
> aplikasi termux
> kopi+rokok ;v
```

### Cara Installnya
Script ini di modifikasi sama saya sendiri UwiwBocah ID.
```bash
> kalo lu belum punya apk termux, download di playstore
> masuk ke apk termux lalu ketik dibawah ini!
> termux-setup-storage
> pkg install git && pkg install wget && pkg install ffmpeg && pkg install nodejs
> apt update && apt upgrade
> git clone https://github.com/Uwiwbocah/Uwiwbocah
> cd Uwiwbocah
> npm i -g cwebp && npm i -g ytdl && npm i  && npm i got && node index js
> Tinggal scan kode qr yeee...done
```

## Features

| UWIW BOT      |                   Feature        |
| :-----------: | :------------------------------: |
|       ✅       | Sticker Creator                  |
|       ✅       | Nulis                            |
|       ✅       | Covid (new)                      |
|       ✅       | Alay (new)                       |
|       ✅       | Lirik (new)                      |
|       ✅       | Foto Anime                       |
|       ✅       | Foto cewek/cowok (new)           |
|       ✅       | Pantun                           |
|       ✅       | Youtube Downloader               |
|       ✅       | Quotes                           |
|       ✅       | Nama (new)                       |
|       ✅       | Foto Anime                       |
|       ✅       | Pasangan (new)                   |
|       ✅       | Sholat (new )                    |
|       ✅       | Suara Google (fix)               |
|       ✅       | Quran                            |
|       ✅       | Youtube MP3 Downloader           |
|       ✅       | Intagram Downloader              |
|       ✅       | Twitter Downloader               |
|       ✅       | Facebook Downloader              |
|       ✅       | TikTok Downloader  (new)         |
|       ✅       | Wikipedia                        |
|       ✅       | Say                              |
|       ✅       | Toxic (new)                      |
|       ✅       | loli                             |
|       ✅       | hentai                           |
|       ✅       | Owner (new)                      |
|       ✅       | kata bijak                       |
|       ✅       | Fakta                            |
|       ✅       | Pokemon                          |
|       ✅       | Info                             |
|       ✅       | Donate                           |
|                   MORE                           |

Ket: Aktiv 24 jam

## Note
BOT INI KHUSUS HP/TERMUX DOANG YAH,JIKA MAU RE-UPLOAD CANTUMKAN NAMA SAYA (UWIWBOCAH ID)

## Sosial Media Admin
* [`Youtube Admin`](BELUMADA)
* [`Instagram Admin`](https://instagram.com/Uwiw_Bocah)
* [`WhatsApp Admin `](https://wa.me/+6281381630954)

